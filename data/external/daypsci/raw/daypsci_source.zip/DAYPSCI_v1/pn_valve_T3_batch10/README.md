# README – Part Marking System Delay T3 Batch 10 (EV Delay)

This file describes the experimental conditions and data characteristics of the Delay Type T3 Batch 10 dataset from DAYPSCI v1, obtained from a Part Marking System affected by sporadic delays in solenoid valves (EVs).


### EXPERIMENT DESCRIPTION

Valve T3 Batch 10 corresponds to a controlled anomaly scenario focused on temporal distortions caused by punctual delays in solenoid valve actuation (EV).

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled delays are introduced at the actuator level through variations in EV response time.

Unlike sensor degradation, these delays affect actuation timing rather than detection.

Key characteristics:

- Batch size: 25  
- Seed: 56  
- Class distribution: None (75% = 19), Sensor (0%), Solenoid valves (25% = 6)  
- Parts with injected faults and affected sensors:  
  - Part 3 (V5 - YC_p)  
  - Part 11 (V2 - YA_m)  
  - Part 14 (V4 - YB_m)  
  - Part 19 (V3 - YB_p)  
  - Part 21 (V6 - YC_m)  
  - Part 24 (V1 - YA_p)  
- Operating mode: Automatic operation with controlled temporal perturbations  
- Anomaly injection: Enabled (sporadic delays affecting EVs)  
- Fault injection type: T3 (punctual delay in solenoid valve actuation)  
- Batch configuration: Event-based anomaly at part level  
- System condition: Operational with localized actuator delays (no hard faults)  


### SYSTEM BEHAVIOR UNDER T3 DELAY

In T3 scenarios (delay affecting EV actuation), the system exhibits localized temporal anomalies without logical inconsistencies.

As a consequence:

- The activation or deactivation of EVs may be delayed  
- The physical execution of transitions is temporally shifted  
- Event sequences remain logically consistent  
- Temporal distortions appear as increased Δt between events  

### DELAY BEHAVIOR (T3)

In this batch, delays are associated with sporadic response latency in solenoid valves (EVs), resulting in localized deviations in process timing.

Key characteristics:

- Delays occur sporadically (non-progressive), as defined by the predefined fault injection plan  
- Only one EV is affected per part  
- No artificial logic manipulation is applied  
- The actuator state remains correct but temporally shifted  

The resulting behavior can be described as:

- Localized temporal perturbations  
- Irregular event timing  
- Non-deterministic execution latency  