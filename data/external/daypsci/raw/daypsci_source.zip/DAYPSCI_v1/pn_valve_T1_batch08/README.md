# README – Part Marking System Fault T1 Batch 08 (EV Stuck OFF)

This file describes the experimental conditions and data characteristics of the Fault Type T1 Batch 08 dataset from DAYPSCI v1, obtained from a Part Marking System affected by a stuck OFF condition in solenoid valves (EVs).


### EXPERIMENT DESCRIPTION

Valve T1 Batch 08 corresponds to a controlled fault scenario focused on actuator anomalies caused by solenoid valves failing to activate (stuck in OFF state).

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while actuator faults are introduced by preventing EV activation when commanded.

Unlike delay-based anomalies, this fault affects the logical behavior of actuation.

Key characteristics:
- Batch size: 25  
- Seed: 56  
- Class distribution: None (75% = 19), Sensor (0%), Solenoid valves (25% = 6)  
- Parts with injected faults and affected sensors:  
  - Part 3 (V5 - YC_p)  
  - Part 11 (V1 - YA_p)  
  - Part 14 (V3 - YB_p)  
  - Part 19 (V3 - YB_p)  
  - Part 21 (V5 - YC_p)  
  - Part 24 (V1 - YA_p)  
- Operating mode: Automatic operation with controlled fault injection  
- Anomaly injection: Enabled (stuck OFF condition in EVs)  
- Fault injection type: T1 (EV stuck OFF)  
- Batch configuration: Event-based fault at part level  
- System condition: Operational with actuator activation failure  


### SYSTEM BEHAVIOR UNDER T1 FAULT

In T1 scenarios (EV stuck OFF), the system exhibits actuator inactivity that may disrupt the expected execution of the process.

As a consequence:

- The EV does not activate when required  
- Expected activation transitions may be missing  
- Subsequent operations may not be executed correctly  
- Event sequences may be incomplete or truncated  

Importantly:

- The anomaly may affect both timing (Δt) and logic  
- The number of events per part may be reduced  
- Missing transitions may prevent normal cycle progression  


### FAULT BEHAVIOR (T1)

In this batch, faults are associated with absence of actuation in solenoid valves (EVs), resulting in deviations in both temporal and logical process behavior.

Key characteristics:

- Fault occurs sporadically according to the predefined injection plan  
- Only one EV is affected per part  
- The actuator fails to activate when commanded  
- Logical sequence is directly affected  

The resulting behavior can be described as:

- Missing actuation events  
- Incomplete or interrupted sequences  
- Loss of expected system transitions  





