# README – Sensor Fault T5 Batch 06 (Glitch)
This file describes the experimental conditions and data characteristics of the Sensor Fault Type T5 Batch 06 dataset from DAYPSCI v1.


### EXPERIMENT DESCRIPTION
Sensor T5 Batch 06 corresponds to a controlled fault injection scenario focused on digital sensor anomalies of type T5 (glitch).
The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled sensor faults are introduced during operation.
The injection of faults is guided by a predefined experimental plan, ensuring a controlled and reproducible selection of affected parts and sensors.

Key characteristics:

- Batch size: 25  
- Seed: 56  
- Class distribution: None (70% = 18), Sensor (30% = 7), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c0)  
  - Part 8 (B2)  
  - Part 11 (a1)  
  - Part 14 (b1)  
  - Part 19 (b0)  
  - Part 21 (c1)  
  - Part 24 (a0)  
- Operating mode: Automatic operation with controlled disturbances
- Anomaly injection: Enabled (sensor faults)
- Fault injection type: T5 (glitch)
- Batch configuration: Event-based fault injection at part level
- System condition: Operational with controlled signal perturbations


### SYSTEM BEHAVIOR UNDER T5 FAULTS
In T5 scenarios (glitch), the fault introduces isolated and instantaneous signal errors in the digital sensor signal.
As a consequence:

- Sensor signals may exhibit short-lived incorrect transitions (spikes or drops)
- The logical state of the sensor remains correct before and after the glitch
- The control logic may react to a spurious transition
- Event sequences may include unexpected transient transitions

Importantly, due to the event-based nature of the CPS:

- Each glitch may generate one or more additional events
- The number of events per part may slightly increase
- Temporal inconsistencies are localized and do not affect the full sequence


### GLITCH BEHAVIOR (T5)
In this batch, glitches are injected at the sensor level using a discrete event-based model.

Key characteristics:

- Glitches are applied to specific sensors on a per-part basis
- Each glitch produces a very short incorrect signal (typically one scan cycle)
- Glitches are non-periodic and randomly distributed in time
- The signal returns immediately to its nominal value after the perturbation

This behavior reflects realistic industrial scenarios such as electrical spikes or communication glitches that briefly disturb sensor readings without causing sustained degradation.




