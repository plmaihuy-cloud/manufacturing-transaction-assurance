# README – Part Marking System Fault T2 Batch 09 (EV Stuck ON)

This file describes the experimental conditions and data characteristics of the Fault Type T2 Batch 09 dataset from DAYPSCI v1, obtained from a Part Marking System affected by a stuck ON condition in solenoid valves (EVs).


### EXPERIMENT DESCRIPTION

Valve T2 Batch 09 corresponds to a controlled fault scenario focused on persistent actuator anomalies caused by solenoid valves remaining stuck in the ON state.

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while actuator faults are introduced through the forced persistence of EV activation.

Unlike delay-based anomalies, this fault affects the logical behavior of actuation.

Key characteristics:
Key characteristics:
- Batch size: 25  
- Seed: 56  
- Class distribution: None (75% = 19), Sensor (0%), Solenoid valves (25% = 6)  
- Parts with injected faults and affected sensors:  
  - Part 3 (V6 - YC_m)  
  - Part 11 (V2 - YA_m)  
  - Part 14 (V4 - YB_m)  
  - Part 19 (V4 - YB_m)  
  - Part 21 (V6 - YC_m)  
  - Part 24 (V2 - YA_m)  
- Operating mode: Automatic operation with controlled fault injection  
- Anomaly injection: Enabled (stuck ON condition in EVs)  
- Fault injection type: T2 (EV stuck ON)  
- Batch configuration: Event-based fault at part level  
- System condition: Operational with abnormal actuator persistence  


### SYSTEM BEHAVIOR UNDER T2 FAULT

In T2 scenarios (EV stuck ON), the system exhibits persistent actuator behavior that may lead to logical inconsistencies in the process.

As a consequence:

- The EV remains activated longer than expected  
- Expected deactivation transitions may be delayed or absent  
- Subsequent operations may be affected  
- Event sequences may deviate from the nominal structure  

Importantly:

- The anomaly may affect both timing (Δt) and logic  
- The number of events per part may vary  
- Additional or missing transitions may appear  


### FAULT BEHAVIOR (T2)

In this batch, faults are associated with persistent activation of solenoid valves (EVs), resulting in deviations in both temporal and logical process behavior.

Key characteristics:

- Fault occurs sporadically according to the predefined injection plan  
- Only one EV is affected per part  
- The actuator remains ON beyond its intended state  
- Logical sequence may be affected  

The resulting behavior can be described as:

- Persistent actuation state  
- Altered event sequences  
- State inconsistency in the control process  