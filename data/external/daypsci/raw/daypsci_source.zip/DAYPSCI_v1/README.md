# DAYPSCI v1 Dataset  
**Detection of Anomalies and Protection of Industrial Cyber-Physical Systems**

## 📄 Official Dataset Description

The official dataset description, including full metadata and methodological details associated with the DOI, is available at:

👉 https://riubu.ubu.es/handle/10259/11686


This repository provides a technical and user-oriented description of the dataset, while experiment-specific details are described in the corresponding batch folders.

## 1. Overview

The DAYPSCI v1 dataset (Detection of Anomalies and Protection of Industrial Cyber-Physical Systems) is an event-based dataset generated using an industrial cyber-physical system (CPS) testbed built around a PLC-controlled part marking station based on Siemens S7-1200 and S7-1500 controllers. The testbed integrates real industrial hardware with digital twin simulation tools, enabling the systematic generation of controlled, flexible, and reproducible experimental scenarios.

The dataset is designed to support the development and evaluation of machine learning methods for anomaly detection and fault classification in industrial CPS.

It includes:

- Normal operation (baseline)
- Sensor faults (T1–T6: stuck-at-0, stuck-at-1, delay, noise, glitch, and degradation anomalies)
- Solenoid valve faults (T1–T3: stuck OFF, stuck ON, and delay anomalies)
- Combined sensor–solenoid valve faults
- Event-based process data (GEMMA-compliant)
- Network traffic captures (Profinet, collected via switch port mirroring)

## 2. System Description

The dataset is generated from an industrial CPS testbed consisting of:

- PLC-based control system (Siemens S7-1500)
- Automated part marking process modeled through a digital twin (PCSIMU-S7-1200)
- Virtualized digital sensors and solenoid valves (electrovalves) within the digital twin environment
- Integration between physical control hardware and digital twin simulation, enabling controlled, flexible, and reproducible experimentation
- Industrial communication via Profinet

The process is modeled according to the GEMMA guide, ensuring well-defined operational states and transitions.

## 3. Data Acquisition Methodology

### 3.1 Event-Based Logging

The dataset follows an **event-based acquisition approach**:

- Each row represents a **state change (event)**
- Events are recorded only when a variable changes
- This minimizes redundancy while preserving system dynamics

Each event includes:

- `Δt` → time elapsed since the previous event  
- `scan_id` → PLC scan cycle identifier  
- `event_order` → execution order within the scan  

This enables accurate reconstruction of temporal and logical behavior.


### 3.2 Temporal Consistency

- Δt > 0 for sequential events  
- Δt = 0 when multiple events occur within a single PLC scan  
- Execution order is preserved using (`scan_id`, `event_order`)  


### 3.3 Δt as a Core Feature

The inter-event time (Δt) is a fundamental feature of the dataset.

Unlike fixed sampling approaches, Δt enables:

- Precise temporal characterization of system dynamics
- Detection of delays, drift, and blocking situations
- Identification of abnormal execution patterns
- Modeling of CPS temporal behavior

This makes the dataset especially suitable for:

- Temporal anomaly detection
- Sequence modeling (e.g., LSTM, GNN)
- Classical machine learning methods (e.g., k-NN, Random Forest, SVM)
- Hybrid and comparative evaluations between classical and deep learning approaches
- Event-based machine learning approaches


## 4. Process Modeling (GEMMA)

The system follows a GEMMA-based operational sequence.

In batches without faults, the system follows a simplified GEMMA sequence:

→ **A1 → F1 → A2 → A1**

The system starts in the initial stopped state (A1). After the start command, it transitions to automatic operation (F1), where it remains throughout the entire batch execution. Once the batch is completed, the system transitions to stop (A2) and returns to the initial stopped state (A1), ready for the next batch.

In batches with faults, the system may follow extended GEMMA sequences such as:

→ **A1 → F1 → D2 → A5 → A1**

or, in more complex recovery scenarios:

→ **A1 → F1 → D2 → A5 → A6 → A1**

GEMMA states are internally encoded using numerical identifiers in the dataset (e.g., 1 → F1, 7 → D2), while the classical GEMMA notation (A1, F1, D2, etc.) is used here for clarity and interpretability.

In this context, these sequences represent the transition from nominal operation to fault detection, handling, and recovery phases.

Where:

- 0 → Initial state (A1)
- 1 → Automatic operation (F1)
- 2 → Manual stop end of cycle (A2)
- 3 → Emergency stop (D1)
- 4 → Manual mode (F4)
- 5 → Fault handling (A5)
- 6 → Preparation / recovery (A6)
- 7 → Fault state (D2)

This structure enables modeling of:

- Normal operation cycles
- Fault occurrence and recovery
- Sequence-based and time-aware anomaly detection


## 5. Dataset Structure

The dataset is organized into **independent batches**, each representing a specific experimental condition.

Each batch includes:

- Event-based data (CSV)
- Processed parts identified by `part_id`
- Labels and fault indicators
- Network captures (PCAPNG)
- Experimental metadata

Each part corresponds to a complete process execution cycle, enabling sequence-based analysis.


## 6. Fault and Anomaly Taxonomy

The dataset includes a comprehensive set of anomalies affecting both the **perception (sensors)** and **execution (solenoid valves)** layers of the CPS.


### 6.1 Sensor Faults (Perception Layer)

- **T1 – Stuck at 0**
  - Constant logical 0
  - Deterministic anomalies

- **T2 – Stuck at 1**
  - Constant logical 1
  - Controlled anomalies with deterministic injection and non-deterministic manifestation

- **T3 – Temporal Delay**
  - Delayed signal transitions
  - Preserves logic but alters timing
  - Due to the sequential and dependency-driven nature of the CPS, delays propagate through the sequence, shifting subsequent events, producing cumulative Δt variations, and typically increasing the overall cycle time of the part

- **T4 – Stochastic Noise**
  - Random short-duration perturbations
  - Generates spurious transitions
  - In this dataset, all perturbations are considered anomalies due to their impact on the observed event sequence
  - These anomalies consistently drive the system into a fault state (GEMMA D2)

- **T5 – Glitch**
  - Instantaneous signal errors
  - Typically occur within one PLC scan cycle
  - Introduce short-duration inconsistencies in the event sequence
  - These anomalies may lead to a fault state (GEMMA D2) depending on whether they affect critical process conditions

- **T6 – Temporal Degradation**
  - Progressive delay in sensor activation
  - Reflects physical process degradation
  - Leads to increasing Δt over time


### 6.2 Solenoid Valve Faults (Execution Layer)

- **T1 – Stuck OFF**
  - No activation when commanded
  - Missing transitions
  - Incomplete sequences (the process cannot complete the full operation cycle, leading the system to a fault state (GEMMA D2))

- **T2 – Stuck ON**
  - Persistent activation
  - Logical inconsistencies due to uncontrolled actuation
  - Altered sequence structure (unexpected activations disrupt the process and ultimately lead the system to a fault state (GEMMA D2))

- **T3 – Actuation Delay**
  - Delayed response without logical failure
  - Preserves logical correctness but alters temporal behavior
  - Due to process dependencies, delays may propagate through the sequence, producing localized or cumulative Δt variations and potentially increasing the cycle time


### 6.3 Combined Faults

- Simultaneous occurrence of sensor and solenoid valve faults (e.g., T1 sensor faults combined with T1 solenoid valve faults affecting the same part)

These introduce:

- Cross-layer inconsistencies between sensing and actuation, where the system neither correctly detects nor correctly executes process conditions
- Reinforced blocking behavior due to the combination of perception and execution failures
- Recovery phases triggered after fault detection (GEMMA D2)
- Significant increases in cycle time due to the cumulative effect of multiple faults within the same process cycle


## 7. CPS Layer Representation

The dataset explicitly models:

- **Perception layer** (sensors), capturing the observed state of the process
- **Execution layer** (solenoid valves), representing the actuation applied to the system
- **Interaction between layers**, reflecting the closed-loop dependencies between sensing and actuation

This enables:

- Root-cause analysis, allowing identification of whether anomalies originate from perception, execution, or their interaction
- Cross-layer anomaly detection, identifying inconsistencies between sensor observations and actuator behavior
- Advanced CPS modeling, capturing the interdependent dynamics of industrial processes


## 8. Temporal vs Logical Anomalies

The dataset distinguishes:

### Logical anomalies
- Affect the correctness of system states  
- Represent deviations where the system reaches invalid or inconsistent states  
- Example: stuck faults (e.g., sensors or solenoid valves remaining in a fixed state)  

### Temporal anomalies
- Affect timing without altering logical correctness  
- The system executes the correct sequence but with altered temporal dynamics  
- Example: delays and temporal degradation (reflected in Δt variations and increased cycle time)  

### Hybrid anomalies
- Combine both logical and temporal effects  
- Introduce inconsistencies in system states along with temporal distortions  
- Example: glitches and combined faults  

This distinction is key for:

- **Model design**, enabling the use of different approaches for logical (e.g., classification) and temporal (e.g., sequence-based) anomalies  
- **Evaluation strategies**, allowing separate analysis of state correctness and temporal behavior  
- **CPS behavior analysis**, providing deeper insight into whether anomalies affect the system logic, timing, or both 


## 9. Ground Truth Generation

Ground truth is derived from a combination of **control system signals** and **externally defined experimental conditions**.

This includes:

- Fault-related signals generated by the PLC (e.g., system fault states such as GEMMA D2)  
- Experimentally defined fault injection indicators (e.g., FSx, TFSx, FCVx, TFCVx)  

This hybrid approach ensures:

- Alignment between system behavior and injected fault conditions  
- Traceability of anomalies to their underlying causes  
- Consistency between experimental design and observed data  

Important:

- **Fault activation ≠ anomaly onset**  
  - The activation of a fault (e.g., via FSx or FCVx) does not necessarily coincide with when its effects become observable in the system  

- **Anomaly labels reflect observable behavior**  
  - Anomalies are defined based on the impact on the process, not solely on fault injection signals  

This separation reflects the distinction between fault injection (cause) and observable system behavior (effect), which may be temporally decoupled.


## 10. Labeling Scheme

- **`anomaly`** → observable effect on the process, generally aligned with the fault injection plan (e.g., sensor or solenoid valve faults affecting a given part); however, propagated anomalies result from the evolution of fault effects through the system  

  - 0 → normal operation  
  - 1 → anomaly in sensors (perception layer)  
  - 2 → anomaly in solenoid valves (execution layer)  
  - 3 → anomaly in both sensors and solenoid valves (combined faults)  
  - 4 → propagated anomaly (resulting from the propagation of fault effects through the process)  

Additional labeling fields:

- `FSx`, `TFSx` → sensor fault indicators from the experimental plan, including fault type classification (T1–T6)  
- `FCVx`, `TFCVx` → solenoid valve fault indicators from the experimental plan, including fault type classification (T1–T3)  

- `fault` → process fault indicator generated by the control system (e.g., transition to a fault state such as GEMMA D2)  

This structure enables linking anomaly detection results with both their underlying causes and system-level consequences.

Supports:

- Binary classification  
- Multi-class classification  
- Root-cause analysis  


## 11. Network Data

Each batch may include network traffic captures obtained via switch port mirroring during process execution.

The captured traffic corresponds exclusively to Profinet communication between PLCs and field devices operating within the controlled CPS environment.

This includes:

- **Profinet traffic captures (PCAPNG format)**  
- Exchange of cyclic process data between the PLC and the digital twin  
- Acyclic communication related to process operation  

This enables:

- Correlation between process behavior and network activity  
- Multi-layer analysis combining CPS data and communication patterns  
- Cybersecurity research in industrial environments 


## 12. Use Cases

The dataset supports:

- Anomaly detection in industrial CPS  
- Fault classification (sensor, solenoid valve, combined)  
- Temporal anomaly detection using Δt  
- Sequence modeling (e.g., LSTM, GNN)  
- Classical machine learning approaches (e.g., k-NN, Random Forest, SVM)  
- Detection of missing and spurious events  
- Cross-layer anomaly detection (process and network)  
- CPS robustness and fault response analysis  
- Cybersecurity research in industrial communication  
- Educational applications


## 13. Experimental Consistency

All batches are generated under:

- Identical hardware setup  
- Consistent PLC logic  
- Same communication infrastructure  
- GEMMA-compliant operation  

Ensuring:

- Reproducibility  
- Consistency  
- Scientific validity


## 14. Data Format

Each dataset file follows a structured tabular format with event-based records.

Example schema:

ts_plc | delta_time_ms | scan_id | event_order | event_id | event_type | edge | part_id | gemma | anomaly | fault | FSx | TFSx | FCVx | TFCVx | a0 | a1 | b0 | b1 | c0 | c1 | ... | batch_id | experiment

Where:

- ts_plc → timestamp generated by the PLC
- delta_time_ms → time elapsed since the previous event (Δt)
- scan_id → PLC scan cycle identifier
- event_order → execution order within the scan
- event_id, event_type, edge → event descriptors related to signal changes
- part_id → identifier of the processed part (process cycle)
- gemma → process state (numerically encoded GEMMA)
- anomaly → anomaly label
- fault → fault indicator from the control system
- FSx, TFSx → sensor fault indicators and type
- FCVx, TFCVx → solenoid valve fault indicators and type
- a0, a1, b0, b1, c0, c1, ... → binary process variables (sensors and actuators)
- batch_id → identifier of the experimental batch
- experiment → experimental scenario identifier

## 15. How to Use

The dataset can be used by loading each batch as an independent event-based dataset.

Each batch may include both:

- Event-based process data (CSV files)  
- Network traffic captures (PCAPNG files)  

Detailed information about each experimental condition is provided in the corresponding experiment-level README files.

Typical workflow:

1. Load event-based data (CSV files)  
2. Group events by `part_id` to reconstruct process cycles  
3. Extract features (e.g., Δt, state transitions, event sequences)  
4. Optionally, analyze network traffic (PCAPNG) to extract communication features  
5. Train and evaluate machine learning models  

The dataset supports:

- Event-level analysis  
- Sequence-based modeling at part level  
- Temporal and state-aware modeling  
- Multi-layer analysis combining process and network data 


## 16. Dataset Structure

The dataset is organized into independent folders, each representing a specific experimental batch.

Folder naming convention:

pn_<scenario>_T<type>_batch<id>

Examples:
- pn_baseline_batch01 → normal operation (no faults)
- pn_sensor_T1_batch02 → sensor fault type T1
- pn_sensor_T6_batch07 → sensor fault type T6
- pn_valve_T1_batch08 → solenoid valve fault type T1
- pn_valve_T3_batch10 → solenoid valve fault type T3
- pn_combined_T1_batch11 → combined sensor and valve faults

## 17. Notes

- Event-based structure implies variable-length sequences  
- Fault density is higher than in real systems (for machine learning purposes)  
- Human intervention may be present in specific scenarios  
- Temporal and logical consistency have been validated 