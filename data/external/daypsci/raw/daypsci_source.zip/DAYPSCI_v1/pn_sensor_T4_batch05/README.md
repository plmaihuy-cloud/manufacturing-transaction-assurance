# README – Sensor Fault T4 Batch 05 (noise)
This file describes the experimental conditions and data characteristics of the Sensor Fault Type T4 Batch 05 dataset from DAYPSCI v1.

### EXPERIMENT DESCRIPTION
Sensor T4 Batch 05 corresponds to a controlled fault injection scenario focused on digital sensor anomalies of type T4 (stochastic noise).
The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled sensor faults are introduced during operation.
The injection of faults is guided by a predefined experimental plan, ensuring a controlled and reproducible selection of affected parts and sensors.
Key characteristics:

- Batch size: 25  
- Seed: 56  
- Class distribution: None (70% = 18), Sensor (30% = 7), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c0)  
  - Part 8 (B2)  
  - Part 11 (a1)  
  - Part 14 (b1)  
  - Part 19 (b0)  
  - Part 21 (c1)  
  - Part 24 (a0)  
- Operating mode: Automatic operation with controlled disturbances
- Anomaly injection: Enabled (sensor faults)
- Fault injection type: T4 (stochastic noise)
- Batch configuration: Event-based fault injection at part level
- System condition: Operational with controlled signal perturbations

### SYSTEM BEHAVIOR UNDER T4 FAULTS
In T4 scenarios (stochastic noise), the fault introduces irregular fluctuations in the digital sensor signal.
As a consequence:

- Sensor signals may exhibit short-lived inversions (temporary incorrect states)
- The logical state of the sensor remains mostly correct over time
- The control logic continues operating but may react to spurious transitions
- Event sequences may include additional unexpected transitions

Importantly, due to the event-based nature of the CPS:

- Each noisy fluctuation may generate additional events
- The number of events per part may increase
- The temporal structure becomes locally irregular without breaking the global process sequence

### STOCHASTIC NOISE BEHAVIOR (T4)
In this batch, noise is injected at the sensor level using a probabilistic model.
Key characteristics:

- Noise is applied to specific sensors on a per-part basis
- Each noise event produces a short-duration incorrect signal
- The duration of perturbations is limited to a few PLC scan cycles
- The activation of noise events is stochastic and non-periodic

The resulting behavior can be described as:

- A sequence of short-duration signal disturbances
- Irregular temporal distribution of perturbations
- Mostly correct signal with intermittent inconsistencies

This behavior reflects realistic industrial scenarios where electrical interference or signal instability introduces temporary inconsistencies without completely corrupting the sensor.




