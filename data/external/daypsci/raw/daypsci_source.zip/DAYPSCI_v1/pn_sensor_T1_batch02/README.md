# README – Sensor Fault T1 Batch 02 (Stuck at 0)

This file describes the experimental conditions and data characteristics of the Sensor Fault Type T1 Batch 02 dataset from DAYPSCI v1.


### EXPERIMENT DESCRIPTION

Sensor T1 Batch 02 corresponds to a controlled fault injection scenario focused on digital sensor anomalies of type T1 (stuck at 0).

The injection of faults is guided by a predefined experimental plan, which determines the selection of affected parts and sensors under controlled and reproducible conditions.

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled sensor faults are introduced during operation.

### Key characteristics

- Batch size: 25  
- Seed: 56  
- Class distribution: None (70% = 18), Sensor (30% = 7), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c0)  
  - Part 8 (B2)  
  - Part 11 (a1)  
  - Part 14 (b1)  
  - Part 19 (b0)  
  - Part 21 (c1)  
  - Part 24 (a0)  
- Operating mode: Automatic operation with controlled disturbances  
- Anomaly injection: Enabled (sensor faults)  
- Fault injection type: T1 (stuck at 0)  
- Batch configuration: Event-based fault injection at part level  
- System condition: Operational with intermittent sensor faults  

### Fault definition

- T1 (stuck at 0): The affected sensor is forced to logical value 0 during the fault event, independently of the real physical condition.


