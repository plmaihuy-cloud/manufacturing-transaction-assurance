# README – Sensor Fault T2 Batch 03 (Stuck at 1)

This file describes the experimental conditions and data characteristics of the Sensor Fault Type T2 Batch 03 dataset from DAYPSCI v1.


### EXPERIMENT DESCRIPTION

Sensor T2 Batch 03 corresponds to a controlled fault injection scenario focused on digital sensor anomalies of type T2 (stuck at 1).

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled sensor faults are introduced during operation.

The injection of faults is guided by a predefined experimental plan, ensuring a controlled and reproducible selection of affected parts and sensors.

Key characteristics:
- Batch size: 25  
- Seed: 56  
- Class distribution: None (70% = 18), Sensor (30% = 7), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c0)  
  - Part 8 (B2)  
  - Part 11 (a1)  
  - Part 14 (b1)  
  - Part 19 (b0)  
  - Part 21 (c1)  
  - Part 24 (a0)  
- Operating mode: Automatic operation with controlled disturbances
- Anomaly injection: Enabled (sensor faults)
- Fault injection type: T2 (stuck at 1)
- Batch configuration: Event-based fault injection at part level
- System condition: Operational with intermittent sensor inconsistencies

### SYSTEM BEHAVIOR UNDER T2 FAULTS

In T2 scenarios (stuck at 1), when the fault affects the part presence sensor (B2), the anomaly does not immediately disrupt the control logic of the system.

Instead, it introduces an inconsistency between sensor readings and the actual physical state of the process.

As a consequence:

- The system continues operating under the assumption that a part is present in the marking station
- The machine executes one or more cycles without a physical part (empty processing)
- No internal fault is triggered by the PLC logic
- The anomaly remains undetected at the control level

This condition may lead to repeated unnecessary operations until it is detected externally.

Process termination:

- The abnormal behavior is identified by the operator
- A manual stop command is issued
- The system transitions through a controlled shutdown sequence (F1 → A2 → A1)
- The machine returns to a safe initial state


