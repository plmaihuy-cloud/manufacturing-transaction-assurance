# README – Part Marking System Degradation T6 Batch 07 (B2 Delay)
his file describes the experimental conditions and data characteristics of the Degradation Type T6 Batch 07 dataset from DAYPSCI v1, obtained from a Part Marking System affected by delays in sensor B2.


### EXPERIMENT DESCRIPTION
Sensor T6 Batch 07 corresponds to a controlled degradation scenario focused on temporal anomalies caused by delays in the digital sensor B2 (part arrival sensor at the marking station).
The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled degradation is introduced through variations in the timing of part arrival affecting sensor B2.


The degradation affects the detection timing of arriving parts, thus directly impacting the control cycle execution.

Key characteristics:
- Batch size: 25  
- Seed: 56  
- Class distribution: None (95% = 24), Sensor (5% = 1), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 11 (B2)  
  - Part 12 (B2) 
  - Part 13 (B2)   
  - Part 14 (B2)  
  - Part 15 (B2)   
  - Part 16 (B2) 
  - Part 17 (B2)  
  - Part 18 (B2)  
  - Part 19 (B2)  
  - Part 20 (B2)  
  - Part 21 (B2)  
- Operating mode: Automatic operation with controlled degradation  
- Anomaly injection: Enabled (timing delays affecting sensor B2)  
- Fault injection type: T6 (progressive delay in B2 activation)  
- Batch configuration: Event-based degradation at part level  
- System condition: Operational with controlled temporal perturbations


### SYSTEM BEHAVIOR UNDER T6 DEGRADATION
In T6 scenarios (degradation affecting the timing of sensor B2), the system exhibits progressive temporal delays without logical inconsistencies.

As a consequence:

- The activation of sensor B2 is progressively delayed  
- The control system waits for B2 before continuing execution  
- Cycle time (e.g., YA_p → YC_m) increases progressively  
- Event sequences remain logically consistent  

Importantly, due to the event-based nature of the CPS:

- Delays manifest as increased time between events  
- The number of events per part remains


### DEGRADATION BEHAVIOR (T6)
In this batch, degradation is associated with delayed activation of sensor B2 (part arrival sensor at the marking station), resulting in temporal deviations in the process execution.

Key characteristics:

- Delays increase progressively across consecutive parts  
- Sensor B2 is activated later due to variations in part arrival timing  
- No artificial signal manipulation is applied  
- The signal remains logically correct but temporally shifted  

The resulting behavior can be described as:

- Progressive temporal drift  
- Delayed event triggering  
- State-dependent execution timing  






