# README – Sensor Fault T3 Batch 04 (delaying)

This file describes the experimental conditions and data characteristics of the Sensor Fault Type T3 Batch 04 dataset from DAYPSCI v1.


### EXPERIMENT DESCRIPTION

Sensor T3 Batch 04 corresponds to a controlled fault injection scenario focused on digital sensor anomalies of type T3 (temporal delay).

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while controlled sensor faults are introduced during operation.

The injection of faults is guided by a predefined experimental plan, ensuring a controlled and reproducible selection of affected parts and sensors.

Key characteristics:

- Batch size: 25  
- Seed: 56  
- Class distribution: None (70% = 18), Sensor (30% = 7), Solenoid valves (0%)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c0)  
  - Part 8 (B2)  
  - Part 11 (a1)  
  - Part 14 (b1)  
  - Part 19 (b0)  
  - Part 21 (c1)  
  - Part 24 (a0)  
- Operating mode: Automatic operation with controlled disturbances
- Anomaly injection: Enabled (sensor faults)
- Fault injection type: T3 (temporal delay)
- Batch configuration: Event-based fault injection at part level
- System condition: Operational with controlled temporal inconsistencies





