# README – Batch 01 (Baseline)

This file describes the experimental conditions and data characteristics of Batch 01 from the DAYPSCI v1 dataset.

## EXPERIMENT DESCRIPTION

Batch 01 corresponds to the baseline scenario, representing normal system operation without any injected anomalies.

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under standard automatic conditions throughout the entire dataset.

No artificial faults or disturbances have been introduced in this experiment.

Key characteristics:


- Batch size: 25
- Seed: 56
- Class distribution: None (100% = 25), Sensor (0%), Solenoid valves (0%)  
- Operating mode: Normal operation (baseline)
- Anomaly injection: None
- Fault injection: None
- System condition: Stable and repeatable industrial process

