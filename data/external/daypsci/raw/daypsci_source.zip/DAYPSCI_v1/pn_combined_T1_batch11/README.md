# README – Part Marking System Fault T1 Batch 11 (Combined Sensor + Solenoid Valve)

This file describes the experimental conditions and data characteristics of the Fault Type T1 Batch 11 dataset from DAYPSCI v1, obtained from a Part Marking System affected by combined faults in sensors and solenoid valves (EVs).


### EXPERIMENT DESCRIPTION

Valve T1 Batch 11 corresponds to a controlled fault scenario focused on logical inconsistencies caused by failures in both sensing and actuation layers of the system.

The industrial cyber-physical system (CPS), based on a PLC-controlled part marking station, operates under automatic conditions while faults are introduced in both sensors (stuck0 signals) and solenoid valves (stuck OFF).

Unlike delay-based anomalies, these faults directly affect the logical behavior of the system and may disrupt the expected execution of the process.

Key characteristics:
- Batch size: 25  
- Seed: 56  
- Class distribution: None (76% = 19), Sensor (12% = 3), Solenoid valves (12% = 3)  
- Parts with injected faults and affected sensors:  
  - Part 3 (c1 - YB_p)  
  - Part 11 (a1)  
  - Part 14 (YA_p)  
  - Part 19 (b0)  
  - Part 21 (YC_p)  
  - Part 24 (a0) 
- Operating mode: Automatic operation with controlled fault injection  
- Anomaly injection: Enabled (combined sensor and actuator faults)  
- Fault injection type: T1 (sensor stuck0 + EV stuck OFF)  
- Batch configuration: Event-based fault at part level  
- System condition: Operational with logical inconsistencies and recovery actions  


### SYSTEM BEHAVIOR UNDER T1 COMBINED FAULTS

In combined T1 scenarios, the system exhibits inconsistencies caused by the interaction between faulty perception (sensor) and faulty execution (actuator).

As a consequence:

- Sensor signals may not reflect the real state of the system  
- Actuators may fail to execute commanded actions  
- The control logic may wait for conditions that are not met  
- Temporary blocking situations may occur during execution  

Importantly:

- These situations generate large Δt values associated with waiting or intervention  
- Event sequences may include interruptions and recovery phases  
- The system may resume normal operation after fault resolution  


### FAULT BEHAVIOR (T1 COMBINED)

In this batch, faults result from the interaction between sensor and actuator failures, leading to complex deviations in both temporal and logical system behavior.

Key characteristics:

- Faults occur according to a predefined injection plan  
- Combined faults are introduced in selected parts (manually defined)  
- Only one sensor and one solenoid valve may be affected per part 
- Faults may lead to temporary system blocking and recovery  

The resulting behavior can be described as:

- Logical inconsistencies  
- Missing or incorrect event transitions  
- Extended waiting times (high Δt)  
- Recovery after fault resolution  